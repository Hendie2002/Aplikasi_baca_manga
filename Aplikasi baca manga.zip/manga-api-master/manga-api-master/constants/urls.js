const baseUrl = 'https://komiku.id/'

module.exports = baseUrl